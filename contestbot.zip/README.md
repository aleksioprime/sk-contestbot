# contestbot

Приложение с админкой и telegram-ботом на Flask

Для запуска в на локальной машине необходимо:

Открыть терминал и выполнить команду:
```
devops\ngrok http 5000
```

Скопировать адрес Forwarding в файл devops/contestbot_runlocal.bat в переменную URL

Открыть другой терминал и запустить данный bat-файл:
```
devops\contestbot_runlocal.bat
```
